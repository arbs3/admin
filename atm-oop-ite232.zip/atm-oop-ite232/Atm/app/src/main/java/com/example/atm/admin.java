package com.example.atm;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import java.util.Map;

public class admin extends AppCompatActivity {

    private LinearLayout userListLayout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin);

        userListLayout = findViewById(R.id.userListLayout);

        // Retrieve the map of users from UserManager
        Map<String, User> users = UserManager.getAllUsers(); // Assuming this method exists

        // Iterate over the users and create UI elements for each user
        for (final Map.Entry<String, User> entry : users.entrySet()) {
            User user = entry.getValue();
            String userInfo = "Name: " + user.getName() + ", Gender: " + user.getGender() +
                    ", Username: " + user.getUsername();

            // Create a button for deleting the user
            Button deleteButton = new Button(this);
            deleteButton.setText("Delete");
            deleteButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    // Delete the user account
                    UserManager.deleteUser(entry.getKey());
                    // Remove the UI element for the deleted user
                    userListLayout.removeView((View) v.getParent());
                }
            });

            // Create a layout for the user info and add the delete button
            LinearLayout userLayout = new LinearLayout(this);
            userLayout.setOrientation(LinearLayout.HORIZONTAL);
            userLayout.addView(deleteButton);

            // Add user info text
            Button userInfoButton = new Button(this);
            userInfoButton.setText(userInfo);
            userLayout.addView(userInfoButton);

            // Add the user layout to the main layout
            userListLayout.addView(userLayout);
        }
    }
}
