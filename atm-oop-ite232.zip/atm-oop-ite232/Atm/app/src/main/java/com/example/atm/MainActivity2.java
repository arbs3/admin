package com.example.atm;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.TextView;

public class MainActivity2 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        // Your existing onCreate() code...

        // Update balance text view
        updateBalanceTextView();

        // Retrieve ImageButton for deposit
        ImageButton imageButton = findViewById(R.id.imageButton);
        imageButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Start the DepositActivity
                Intent depositIntent = new Intent(MainActivity2.this, transfer.class);
                startActivity(depositIntent);
            }
        });

        // Retrieve ImageButton for transfer
        ImageButton transferButton = findViewById(R.id.buttonDeposit);
        transferButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Start the TransferActivity
                Intent transferIntent = new Intent(MainActivity2.this, deposit.class);
                startActivity(transferIntent);
            }
        });

        // Retrieve ImageButton for withdraw
        ImageButton withdrawButton = findViewById(R.id.buttonWithdraw);
        withdrawButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Start the WithdrawActivity
                Intent withdrawIntent = new Intent(MainActivity2.this, withdraw.class);
                startActivity(withdrawIntent);
            }
        });

        // Retrieve ImageButton for admin
        ImageButton adminButton = findViewById(R.id.buttonAdmin);
        adminButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Start the AdminLoginActivity
                Intent adminIntent = new Intent(MainActivity2.this, adminlogin.class);
                startActivity(adminIntent);
            }
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        // Update balance text view every time MainActivity2 resumes
        updateBalanceTextView();
    }

    private void updateBalanceTextView() {
        TextView balanceTextView = findViewById(R.id.balanceTextView);
        balanceTextView.setText("$" + BalanceManager.getBalance());
    }
}
