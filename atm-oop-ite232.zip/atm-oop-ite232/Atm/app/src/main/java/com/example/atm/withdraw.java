package com.example.atm;

// WithdrawActivity.java
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class withdraw extends AppCompatActivity {

    private EditText editTextWithdrawAmount;
    private Button buttonWithdraw;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_withdraw);

        editTextWithdrawAmount = findViewById(R.id.editTextWithdrawAmount);
        buttonWithdraw = findViewById(R.id.buttonWithdraw);

        buttonWithdraw.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                withdrawMoney();
            }
        });
    }

    private void withdrawMoney() {
        String amountStr = editTextWithdrawAmount.getText().toString().trim();

        if (TextUtils.isEmpty(amountStr)) {
            Toast.makeText(this, "Please enter the amount to withdraw", Toast.LENGTH_SHORT).show();
            return;
        }

        double amount = Double.parseDouble(amountStr);

        if (amount <= 0) {
            Toast.makeText(this, "Invalid amount", Toast.LENGTH_SHORT).show();
            return;
        }

        if (amount > BalanceManager.getBalance()) {
            Toast.makeText(this, "Insufficient balance", Toast.LENGTH_SHORT).show();
            return;
        }

        BalanceManager.withdraw(amount);
        Toast.makeText(this, "Withdrawal successful: $" + amount, Toast.LENGTH_SHORT).show();
        finish(); // Finish the activity after withdrawal
    }
}
