package com.example.atm;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class deposit extends AppCompatActivity {
    private EditText editTextDepositAmount;
    private Button buttonDeposit;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_deposit);

        // Initialize views
        editTextDepositAmount = findViewById(R.id.editTextDepositAmount);
        buttonDeposit = findViewById(R.id.buttonDeposit);

        buttonDeposit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                depositMoney();
            }
        });
    }

    private void depositMoney() {
        String amountString = editTextDepositAmount.getText().toString().trim();

        if (TextUtils.isEmpty(amountString)) {
            // If amount is empty, show error and return
            editTextDepositAmount.setError("Amount cannot be empty");
            return;
        }

        try {
            // Parse amount to double
            double amount = Double.parseDouble(amountString);

            if (amount <= 0) {
                // If amount is non-positive, show error and return
                editTextDepositAmount.setError("Amount must be greater than zero");
                return;
            }

            // Deposit the amount
            BalanceManager.deposit(amount);
            Toast.makeText(this, "Deposit successful: $" + amount, Toast.LENGTH_SHORT).show();
        } catch (NumberFormatException e) {
            // Handle parsing error
            editTextDepositAmount.setError("Invalid amount format");
        }
    }
}
