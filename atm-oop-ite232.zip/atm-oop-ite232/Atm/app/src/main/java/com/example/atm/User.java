package com.example.atm;

public class User {
    private String name;
    private String gender;
    private String username;
    private String password;

    public User(String name, String gender, String username, String password) {
        this.name = name;
        this.gender = gender;
        this.username = username;
        this.password = password;
    }

    // Getters and setters
    public String getName() {
        return name;
    }

    public String getGender() {
        return gender;
    }

    public String getUsername() {
        return username;
    }

    public String getPassword() {
        return password;
    }
}

