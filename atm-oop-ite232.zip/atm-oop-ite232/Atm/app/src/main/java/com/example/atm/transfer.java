package com.example.atm;

// TransferActivity.java
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class transfer extends AppCompatActivity {

    private EditText editTextReceiverName, editTextBankID, editTextAmount;
    private Button buttonTransfer;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_transfer);

        editTextReceiverName = findViewById(R.id.editTextReceiverName);
        editTextBankID = findViewById(R.id.editTextBankID);
        editTextAmount = findViewById(R.id.editTextAmount);
        buttonTransfer = findViewById(R.id.buttonTransfer);

        buttonTransfer.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                transferMoney();
            }
        });
    }

    private void transferMoney() {
        String receiverName = editTextReceiverName.getText().toString().trim();
        String bankID = editTextBankID.getText().toString().trim();
        String amountStr = editTextAmount.getText().toString().trim();

        if (TextUtils.isEmpty(receiverName)) {
            editTextReceiverName.setError("Receiver's Name is required");
            editTextReceiverName.requestFocus();
            return;
        }

        if (TextUtils.isEmpty(bankID)) {
            editTextBankID.setError("Receiver's Bank ID is required");
            editTextBankID.requestFocus();
            return;
        }

        if (TextUtils.isEmpty(amountStr)) {
            editTextAmount.setError("Amount to Transfer is required");
            editTextAmount.requestFocus();
            return;
        }

        double amount = Double.parseDouble(amountStr);

        if (amount > BalanceManager.getBalance()) {
            Toast.makeText(this, "Insufficient balance", Toast.LENGTH_SHORT).show();
            return;
        }

        BalanceManager.transfer(amount);
        Toast.makeText(this, "Transfer successful: " + amount + " to " + receiverName + " (" + bankID + ")", Toast.LENGTH_SHORT).show();

        // Clear fields after successful transfer
        editTextReceiverName.getText().clear();
        editTextBankID.getText().clear();
        editTextAmount.getText().clear();
    }
}
