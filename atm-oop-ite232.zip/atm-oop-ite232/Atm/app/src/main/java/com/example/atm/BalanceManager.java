package com.example.atm;
public class BalanceManager {
    private static double balance = 0.00;

    public static double getBalance() {
        return balance;
    }

    public static void deposit(double amount) {
        balance += amount;
    }

    public static void withdraw(double amount) {
        if (amount <= balance) {
            balance -= amount;
        } else {

            System.err.println("Insufficient funds for withdrawal.");
        }
    }

    public static void transfer(double amount) {
        if (amount <= balance) {
            balance -= amount;
        } else {
            
            System.err.println("Insufficient funds for transfer.");
        }
    }
}
