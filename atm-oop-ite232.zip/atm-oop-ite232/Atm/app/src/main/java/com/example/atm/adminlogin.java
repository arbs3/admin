package com.example.atm;


import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class adminlogin extends AppCompatActivity {

    private EditText editTextUsername;
    private Button buttonLogin;
    private TextView signupTextView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_adminlogin);

        editTextUsername = findViewById(R.id.editTextUsername);
        buttonLogin = findViewById(R.id.buttonLogin);
        signupTextView = findViewById(R.id.signupTextView);

        buttonLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String username = editTextUsername.getText().toString().trim();

                // Basic validation
                if (username.isEmpty()) {
                    Toast.makeText(adminlogin.this, "Please enter pin", Toast.LENGTH_SHORT).show();
                } else {
                    // Perform login logic
                    if (username.equals("0000")) {
                        // Successful login
                        Toast.makeText(adminlogin.this, "Login successful", Toast.LENGTH_SHORT).show();
                        // Navigate to AdminActivity
                        Intent intent = new Intent(adminlogin.this, admin.class);
                        startActivity(intent);
                        finish(); // Finish adminlogin activity
                    } else {
                        // Failed login
                        Toast.makeText(adminlogin.this, "invalid pin", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });
    }
}