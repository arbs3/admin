package com.example.atm;

import java.util.HashMap;
import java.util.Map;

public class UserManager {
    private static final Map<String, User> users = new HashMap<>();

    public static void createUser(String name, String gender, String username, String password) {
        users.put(username, new User(name, gender, username, password));
    }

    public static boolean authenticate(String username, String password) {
        User user = users.get(username);
        return user != null && user.getPassword().equals(password);
    }

    public static Map<String, User> getAllUsers() {
        return users;
    }

    public static void deleteUser(String username) {
        users.remove(username);
    }
}
